function Message(){
    const hello = "Hada";
    return <h1>Hello from {hello}</h1>
}
export default Message;