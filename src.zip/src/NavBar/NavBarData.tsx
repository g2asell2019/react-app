export default interface NavBarData{
    name: string;
    SubNavData?: NavBarData[];
}
